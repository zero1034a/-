---
name: "Bug fix"
about: Fix a bug

---

Fixes a bug and Closes an issue